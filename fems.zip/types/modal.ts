export type TModalType = "update" | "add";
