export enum ETeacher {
  S100 = 100,
  S200 = 200,
}
