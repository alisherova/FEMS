export interface ICourse {
  id: number;
  name: string;
  company_id: string;
  status: 100 | 200 | 300;
}
