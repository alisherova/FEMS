export interface ILessonTime {
  id: number;
  time: string;
  duration: null;
}
