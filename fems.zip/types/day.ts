export interface IDay {
  id: number;
  company_id: number;
  course_id: number;
  name: string;
  status: null | string;
}
