export interface TLeadActions {
  action: number;
  datetime: string;
  lead_id: number;
}
