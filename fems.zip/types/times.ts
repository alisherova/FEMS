export interface ITimes {
  id: number;
  company_id: number;
  course_id: number;
  time: string;
  duration: null | string;
}
