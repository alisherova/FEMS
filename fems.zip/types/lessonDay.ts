export interface ILessonDay {
  id: number;
  name: string;
  status: null;
}
