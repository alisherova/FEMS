export interface IUserPhone {
  id: number;
  type: 100 | 200 | 300;
  phone_number: string;
  is_confirmed: number;
}
