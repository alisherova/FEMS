export interface ITeacher {
  id?: string;
  firstname: string;
  lastname: string;
  user_id: string;
  free_place?: string;
}
