import styled from "@emotion/styled"; 

export const Wrapper = styled.div`
border-radius: 12px;
margin: 24px; 

.employeesTitle{
    font-size: 12px;
    font-weight: 600;
}
`;

export const DetailsContainer = styled.div`
background-color: white;
display: flex; 
padding: 0 24px;
border-radius: 12px;
border: 1px solid #E2E8F0;
margin-top: 16px;

p{
    font-family: 'Inter';
    display: inline-block;
    font-size: 14px; 
}

span{
    font-family: 'Inter';
    display: block;
    color: #9CA3AF;
    text-transform: uppercase; 
    font-size: 12px;
}

.borderSpan{
    display: inline-block;
background-color: #E2E8F0;
width: 1px;
height: 100 !important%;
}
`;

export const UserInfo = styled.div`
    display: flex;
    width: 20%; 
    flex-direction: column;
    justify-content: center;
    align-items: center;
    padding-top: 46px;
    padding-bottom: 46px;
    padding-right: 24px;

    .userName{
        font-size: 20px;
        font-weight: bold;
        margin-top: 24px;
    }

    .userStatus{
        font-size: 14px;
        margin-top: 8px;
        margin-bottom: 16px;
    }

    .userInfoBtn{
        width: 100%;
        height: 40px;
        border-radius: 12px;
        background-color:#E2E8F0;
        color: #fff;
    }
`;

export const UserDetails = styled.div` 
width: 80%;
display: flex; 
flex-wrap: wrap;
padding-left: 40px; 
padding-top: 46px;

p{
    width: 33%;
    margin-bottom: 40px;
}
`
