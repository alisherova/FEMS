export type TLoginForm = {
    phoneNumber: string;
    password: string;
};