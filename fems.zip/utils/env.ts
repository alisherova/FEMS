export default {
  fileUpload: process.env.NEXT_PUBLIC_FILE_UPLOAD_URL,
  api: process.env.NEXT_PUBLIC_API_URL,
  auth: process.env.NEXT_PUBLIC_API_AUTH,
  token: process.env.NEXT_PUBLIC_COMPANY_TOKEN,
  key: process.env.NEXT_PUBLIC_PRIVATE_KEY,
};
