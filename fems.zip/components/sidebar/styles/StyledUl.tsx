import styled from '@emotion/styled';

export const StyledUl = styled.ul`
  list-style-type: none;
  padding: 0;
  margin: 0;
`;
