import {FC} from "react";

const Hello: FC = () => {
    return (
        <h1>Hello World</h1>
    )
}

export default Hello;