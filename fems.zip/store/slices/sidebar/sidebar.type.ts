export interface ISidebarStore {
    isOpen?: sidebarMenu;
}

export interface sidebarMenu {
    id: number;
    isOpen: boolean;
}
