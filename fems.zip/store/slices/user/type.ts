export type TUser = {
    user: any;
    isLoading: boolean;
};
